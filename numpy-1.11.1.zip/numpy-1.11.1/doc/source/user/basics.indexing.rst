.. _basics.indexing:

********
Indexing
********

.. seealso:: :ref:`Indexing routines <routines.indexing>`

.. automodule:: numpy.doc.indexing
