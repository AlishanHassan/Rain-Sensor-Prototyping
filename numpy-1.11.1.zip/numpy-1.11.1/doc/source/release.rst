*************
Release Notes
*************

.. include:: ../release/1.11.1-notes.rst
.. include:: ../release/1.11.0-notes.rst
.. include:: ../release/1.10.4-notes.rst
.. include:: ../release/1.10.3-notes.rst
.. include:: ../release/1.10.2-notes.rst
.. include:: ../release/1.10.1-notes.rst
.. include:: ../release/1.10.0-notes.rst
.. include:: ../release/1.9.2-notes.rst
.. include:: ../release/1.9.1-notes.rst
.. include:: ../release/1.9.0-notes.rst
.. include:: ../release/1.8.2-notes.rst
.. include:: ../release/1.8.1-notes.rst
.. include:: ../release/1.8.0-notes.rst
.. include:: ../release/1.7.2-notes.rst
.. include:: ../release/1.7.1-notes.rst
.. include:: ../release/1.7.0-notes.rst
.. include:: ../release/1.6.2-notes.rst
.. include:: ../release/1.6.1-notes.rst
.. include:: ../release/1.6.0-notes.rst
.. include:: ../release/1.5.0-notes.rst
.. include:: ../release/1.4.0-notes.rst
.. include:: ../release/1.3.0-notes.rst
